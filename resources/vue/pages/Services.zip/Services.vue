<template>
    <div>
        <div id="blog" class="bg-gray-100 px-4 xl:px-0 py-12">
                <div class="mx-auto container  mt-16">
                    <h1 class="text-center text-3xl lg:text-5xl tracking-wider text-gray-900">Our Services</h1>
                    <div class="mt-12 lg:mt-24">
                        <div class="grid sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-2 gap-8">
                            <div>
                                <img class="w-full rounded-t-3xl" src="/images/services/GST-return.webp" alt="GST Return" />
                                <div class="py-4 px-8 w-full flex justify-between bg-indigo-700">
                                    <p class="text-sm text-white font-semibold tracking-wide">GST Return</p>
                                    <p class="text-sm text-white font-semibold tracking-wide">13TH Oct, 2020</p>
                                </div>
                                <div class="bg-white px-10 py-6 rounded-bl-3xl rounded-br-3xl">
                                    <h1 class="text-4xl text-gray-900 font-semibold tracking-wider">GST Return</h1>
                                    <p class="text-gray-700 text-base lg:text-lg lg:leading-8 tracking-wide mt-6 w-11/12">GST return is a document that will contain all the details of your sales, purchases, tax collected on sales (output tax), and tax paid on purchases (input tax). Once you file GST returns, you will need to pay the resulting tax liability (money that you owe the government).</p>
                                    <div class="w-full mt-4 justify-end flex items-center cursor-pointer">
                                        <p class="text-base tracking-wide text-indigo-500">Read more</p>
                                        <svg class="ml-3 lg:ml-6" xmlns="http://www.w3.org/2000/svg" width="20" height="18" viewBox="0 0 20 18" fill="none">
                                            <path d="M11.7998 1L18.9998 8.53662L11.7998 16.0732" stroke="#4338ca" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                            <path d="M1 8.53662H19" stroke="#4338ca" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </div>
                                    <div class="h-5 w-2"></div>
                                </div>
                            </div>
                            <div>
                                <div class="grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 gap-8">
                                    <div>
                                        <img class="w-full rounded-t-3xl md:h-48" src="/images/services/TDS-Return.jpg" alt="TDS Return" />
                                        <div class="py-2 px-4 w-full flex justify-between bg-indigo-700">
                                            <p class="text-sm text-white font-semibold tracking-wide">Bruce Wayne</p>
                                            <p class="text-sm text-white font-semibold tracking-wide">13TH Oct, 2020</p>
                                        </div>
                                        <div class="bg-white px-3 lg:px-6 py-4 rounded-bl-3xl rounded-br-3xl">
                                            <h1 class="text-lg text-gray-900 font-semibold tracking-wider">TDS Return</h1>
                                            <p class="text-gray-700 text-sm lg:text-base lg:leading-8 pr-4 tracking-wide mt-2">As per this concept, a person (deductor) who is liable to make payment of specified nature to any other person .</p>
                                        </div>
                                    </div>
                                    <div>
                                        <img class="w-full rounded-t-3xl md:h-48" src="/images/services/roc-filing.jpg" alt="ROC filling" />
                                        <div class="py-2 px-4 w-full flex justify-between bg-indigo-700">
                                            <p class="text-sm text-white font-semibold tracking-wide">Bruce Wayne</p>
                                            <p class="text-sm text-white font-semibold tracking-wide">13TH Oct, 2020</p>
                                        </div>
                                        <div class="bg-white px-3 lg:px-6 py-4 rounded-bl-3xl rounded-br-3xl">
                                            <h1 class="text-lg text-gray-900 font-semibold tracking-wider">ROC Filling</h1>
                                            <p class="text-gray-700 text-sm lg:text-base lg:leading-8 pr-4 tracking-wide mt-2">As a part of Annual e-Filing, Companies incorporated under the Companies Act, 1956 are required to efile the.</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="mt-10 grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 gap-8">
                                    <div>
                                        <img class="w-full rounded-t-3xl md:h-48" src="/images/services/legal-&-compliance-header.jpeg" alt="Legal Complains" />
                                        <div class="py-2 px-4 w-full flex justify-between bg-indigo-700">
                                            <p class="text-sm text-white font-semibold tracking-wide">Bruce Wayne</p>
                                            <p class="text-sm text-white font-semibold tracking-wide">13TH Oct, 2020</p>
                                        </div>
                                        <div class="bg-white px-3 lg:px-6 py-4 rounded-bl-3xl rounded-br-3xl">
                                            <h1 class="text-lg text-gray-900 font-semibold tracking-wider">Legal-&-Compliance</h1>
                                            <p class="text-gray-700 text-sm lg:text-base lg:leading-8 pr-4 tracking-wide mt-2"> In legal terminology, a complaint is any formal legal document that sets out the facts and legal reasons.</p>
                                        </div>
                                    </div>
                                    <div>
                                        <img class="w-full rounded-t-3xl md:h-48" src="/images/services/Digital-signature.jpeg" alt="worker" />
                                        <div class="py-2 px-4 w-full flex justify-between bg-indigo-700">
                                            <p class="text-sm text-white font-semibold tracking-wide">Bruce Wayne</p>
                                            <p class="text-sm text-white font-semibold tracking-wide">13TH Oct, 2020</p>
                                        </div>
                                        <div class="bg-white px-3 lg:px-6 py-4 rounded-bl-3xl rounded-br-3xl">
                                            <h1 class="text-lg text-gray-900 font-semibold tracking-wider">Digital Signature</h1>
                                            <p class="text-gray-700 text-sm lg:text-base lg:leading-8 pr-4 tracking-wide mt-2">A digital signature is a mathematical scheme for verifying the authenticity of digital messages or documents.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
</template>

<script>
    export default {
        name: "OurServices",
        currentImg:''
    }
</script>

<style scoped>
@import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap");
.f-f-p {
    font-family: "Poppins", sans-serif;
}
</style>




<!--<section id="team" class="team services section-bg  mt-16" style="background-image: url('/images/background/all-bg2.webp'); background-repeat: no-repeat ; background-size: cover;">-->
<!--<div class="container" data-aos="fade-up">-->
<!--    <div class="section-title">-->
<!--        <h2>Services</h2>-->
<!--        <p>Content.</p>-->
<!--    </div>-->
<!--    <div class="grid justify-items-center">-->
<!--        <div class="w-full flex flex-col md:flex-row items-center justify-center">-->
<!--            <div class="xl:w-5/12 sm:w-w-10/12 w-full 2xl:w-4/12 flex flex-col items-center py-16 md:py-12 m-2.5 bg-gradient-to-r from-indigo-700 to-purple-500 rounded-lg">-->
<!--                <div class="w-full flex items-center justify-center">-->
<!--                    <div class="flex flex-col items-center">-->
<!--                        <img tabindex="0" class="focus:outline-none" src="https://cdn.tuk.dev/assets/templates/olympus/profile.png" alt="man avatar" />-->
<!--                        <p tabindex="0" class="focus:outline-none mt-2 text-xs sm:text-sm md:text-base font-semibold text-center text-white">Book Heeping</p>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="flex items-center mt-7">-->
<!--                    <div class="">-->
<!--                        <p tabindex="0" class="focus:outline-none text-xs text-gray-300">Products</p>-->
<!--                        <p tabindex="0" class="focus:outline-none mt-2 text-base sm:text-lg md:text-xl 2xl:text-2xl text-gray-50">28</p>-->
<!--                    </div>-->
<!--                    <div class="ml-12">-->
<!--                        <p tabindex="0" class="focus:outline-none text-xs text-gray-300">Revenue</p>-->
<!--                        <p tabindex="0" class="focus:outline-none mt-2 text-base sm:text-lg md:text-xl 2xl:text-2xl text-gray-50">$2890</p>-->
<!--                    </div>-->
<!--                    <div class="ml-12">-->
<!--                        <p tabindex="0" class="focus:outline-none text-xs text-gray-300">Average</p>-->
<!--                        <p tabindex="0" class="focus:outline-none mt-2 text-base sm:text-lg md:text-xl 2xl:text-2xl text-gray-50">$169</p>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="xl:w-5/12 sm:w-w-10/12 w-full 2xl:w-4/12 flex flex-col items-center py-16 md:py-12 m-2.5 bg-gradient-to-r from-indigo-700 to-purple-500 rounded-lg">-->
<!--                <div class="w-full flex items-center justify-center">-->
<!--                    <div class="flex flex-col items-center">-->
<!--                        <img tabindex="0" class="focus:outline-none" src="https://cdn.tuk.dev/assets/templates/olympus/profile.png" alt="man avatar" />-->
<!--                        <p tabindex="0" class="focus:outline-none mt-2 text-xs sm:text-sm md:text-base font-semibold text-center text-white">Book</p>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="flex items-center mt-7">-->
<!--                    <div class="">-->
<!--                        <p tabindex="0" class="focus:outline-none text-xs text-gray-300">Products</p>-->
<!--                        <p tabindex="0" class="focus:outline-none mt-2 text-base sm:text-lg md:text-xl 2xl:text-2xl text-gray-50">28</p>-->
<!--                    </div>-->
<!--                    <div class="ml-12">-->
<!--                        <p tabindex="0" class="focus:outline-none text-xs text-gray-300">Revenue</p>-->
<!--                        <p tabindex="0" class="focus:outline-none mt-2 text-base sm:text-lg md:text-xl 2xl:text-2xl text-gray-50">$2890</p>-->
<!--                    </div>-->
<!--                    <div class="ml-12">-->
<!--                        <p tabindex="0" class="focus:outline-none text-xs text-gray-300">Average</p>-->
<!--                        <p tabindex="0" class="focus:outline-none mt-2 text-base sm:text-lg md:text-xl 2xl:text-2xl text-gray-50">$169</p>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--            &lt;!&ndash;                            <div class="flex flex-col w-full xl:w-5/12 sm:w-w-10/12 xl:h-3/4">&ndash;&gt;-->
<!--            &lt;!&ndash;                                <div class=" w-full xl:h-1/2 flex flex-col items-center py-16 xl:h-1/2 md:py-12 md:mx-2.5 xl:mb-2.5 bg-gradient-to-r from-indigo-700 to-purple-500 rounded-lg">&ndash;&gt;-->
<!--            &lt;!&ndash;                                    <div class="w-full flex items-center justify-center">&ndash;&gt;-->
<!--            &lt;!&ndash;                                        <div class="flex flex-col items-center">&ndash;&gt;-->
<!--            &lt;!&ndash;                                            <img tabindex="0" class="focus:outline-none" src="https://cdn.tuk.dev/assets/templates/olympus/profile.png" alt="man avatar" />&ndash;&gt;-->
<!--            &lt;!&ndash;                                            <p tabindex="0" class="focus:outline-none mt-2 text-xs sm:text-sm md:text-base font-semibold text-center text-white">Part</p>&ndash;&gt;-->
<!--            &lt;!&ndash;                                        </div>&ndash;&gt;-->
<!--            &lt;!&ndash;                                    </div>&ndash;&gt;-->
<!--            &lt;!&ndash;                                </div>&ndash;&gt;-->
<!--            &lt;!&ndash;                                <div class="w-full  xl:h-1/2 flex flex-col items-center py-16 xl:h-1/2 md:py-12 md:mx-2.5 xl:mt-2.5 mt-2.5 bg-gradient-to-r from-indigo-700 to-purple-500 rounded-lg">&ndash;&gt;-->
<!--            &lt;!&ndash;                                    <div class="w-full flex items-center justify-center">&ndash;&gt;-->
<!--            &lt;!&ndash;                                        <div class="flex flex-col items-center">&ndash;&gt;-->
<!--            &lt;!&ndash;                                            <img tabindex="0" class="focus:outline-none" src="https://cdn.tuk.dev/assets/templates/olympus/profile.png" alt="man avatar" />&ndash;&gt;-->
<!--            &lt;!&ndash;                                            <p tabindex="0" class="focus:outline-none mt-2 text-xs sm:text-sm md:text-base font-semibold text-center text-white">Collection</p>&ndash;&gt;-->
<!--            &lt;!&ndash;                                        </div>&ndash;&gt;-->
<!--            &lt;!&ndash;                                    </div>&ndash;&gt;-->

<!--            &lt;!&ndash;                                </div>&ndash;&gt;-->
<!--            &lt;!&ndash;                            </div>&ndash;&gt;-->
<!--        </div>-->
<!--        <div class="row lg:w-10/12 p-8">-->
<!--            <div class="col-lg-4 p-8">-->
<!--                <img src="/images/services/tax return1.jpg" class="img-fluid border rounded-md shadow-lg lg:mb-8" alt="" data-aos="zoom-in" data-aos-delay="100">-->
<!--                <span class="text-2xl antialiased font-bold font-mono text-black">Income Tax Return</span>-->
<!--                <p class="font-serif">-->
<!--                    Income tax return is the form in which assessee files information about his/her income and tax thereon to Income Tax Department. Various forms are ITR 1, ITR 2, ITR 3, ITR 4, ITR 5, ITR 6 and ITR 7. When you file a belated return, you are not allowed to carry forward certain losses.-->
<!--                </p>-->
<!--            </div>-->
<!--            <div class="col-lg-4 p-8">-->
<!--                <img src="/images/services/GST-return.webp" class="img-fluid border rounded-md shadow-lg lg:mb-8" alt="" data-aos="zoom-in" data-aos-delay="100">-->
<!--                <span class="text-2xl antialiased font-bold font-mono text-black">GST Return</span>-->
<!--                <p class="font-serif">-->
<!--                    GST return is a document that will contain all the details of your sales, purchases, tax collected on sales (output tax), and tax paid on purchases (input tax). Once you file GST returns, you will need to pay the resulting tax liability (money that you owe the government)-->
<!--                </p>-->
<!--            </div>-->
<!--            <div class="col-lg-4 p-8">-->
<!--                <img src="/images/services/TDS-Return.jpg" class="img-fluid border rounded-md shadow-lg lg:mb-8" alt="" data-aos="zoom-in" data-aos-delay="100">-->
<!--                <span class="text-2xl antialiased font-bold font-mono text-black">TDS Return</span>-->
<!--                <p class="font-serif">-->
<!--                    The concept of TDS was introduced with an aim to collect tax from the very source of income. As per this concept, a person (deductor) who is liable to make payment of specified nature to any other person (deductee) shall deduct tax at source and remit the same into the account of the Central Government.-->
<!--                </p>-->
<!--            </div>-->

<!--            <div class="col-lg-4 p-8">-->
<!--                <img src="/images/services/roc-filing.jpg" class="w-full border rounded-md shadow-lg lg:mb-8 " alt="" data-aos="zoom-in" data-aos-delay="100">-->
<!--                <span class="text-2xl antialiased font-bold font-mono text-black">ROC Filling</span>-->
<!--                <p class="font-serif">-->
<!--                    As a part of Annual e-Filing, Companies incorporated under the Companies Act, 1956 are required to efile the following documents with the Registrar of Companies (RoC): Balance-Sheet: Form 23AC to be filed by all Companies-->
<!--                </p>-->
<!--            </div>-->
<!--            <div class="col-lg-4 p-8">-->
<!--                <img src="/images/services/legal-&-compliance-header.jpeg" class="w-full border rounded-md shadow-lg lg:mb-8 " alt="" data-aos="zoom-in" data-aos-delay="100">-->
<!--                <span class="text-2xl antialiased font-bold font-mono text-black">Other Legal Compliance</span>-->
<!--                <p class="font-serif">-->
<!--                    In legal terminology, a complaint is any formal legal document that sets out the facts and legal reasons (see: cause of action) that the filing party or parties (the plaintiff(s)) believes are sufficient to support a claim against the party or parties against whom the claim is brought (the defendant(s)) that entitles-->
<!--                </p>-->
<!--            </div>-->
<!--            <div class="col-lg-4 p-8">-->
<!--                <img src="/images/services/Digital-signature.jpeg" class="img-fluid border rounded-md shadow-lg lg:mb-8" alt="" data-aos="zoom-in" data-aos-delay="100">-->
<!--                <span class="text-2xl antialiased font-bold font-mono text-black">Digital Signature</span>-->
<!--                <p class="font-serif">-->
<!--                    A digital signature is a mathematical scheme for verifying the authenticity of digital messages or documents. A valid digital signature, where the prerequisites are satisfied, gives a recipient very high confidence that the message was created by a known sender, and that the message was not altered in transit.-->
<!--                </p>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->
<!--</section>-->
