<template>
    <main id="main">
        <section id="services" class="services section-bg bg-gradient-to-r from-cyan-500 to-blue-500">
            <div class="container">
                <div class="section-title text-white">
                    <h2 class="text-white">Registration</h2>
                    <h4>{{title}}</h4>
                </div>
            </div>
            <!--            <div class="d-flex font-mono text-center text-white flex justify-center">-->
            <!--                <div>-->
            <!--                    <h1 class="text-5xl">1</h1>-->
            <!--                    <span class="text-sm">Mobile <br> verification</span>-->
            <!--                </div>-->
            <!--                <h1 class="border-b-2 border-bottom-2 w-24 h-1"></h1>-->
            <!--                <div>-->
            <!--                    <h1 class="text-5xl">2</h1>-->
            <!--                    <span class="text-sm">Email <br> verification</span>-->
            <!--                </div>-->
            <!--            </div>-->
            <div class="max-w-xl mx-auto h-screen ">
                <div class="md:col-span-1">
                    <div class="px-4 sm:px-0">
                        <!--  Step 1-->
                        <form v-if="personal">
                            <div class="overflow-hidden shadow sm:rounded-md px-4 py-2 sm:p-6 text-white">
                                <img class="w-full" src="/images/account-assets-audit-bank-bookkeeping-finance-concept.jpg" alt="Sunset in the mountains">
                                <div class="lg:flex justify-content-between mt-4">
                                    <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-5 p-1">
                                        <div class="form-group">
                                            <input type="text" name="name" autocomplete="off"  :class="className.input" v-model="form.fname" placeholder="First Name" required>
                                            <span class="text-red-700 mb-30" v-if="formErrors.fname" v-text="formErrors.fname"/>
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-5 p-1">
                                        <div class="form-group">
                                            <input type="text" name="name" autocomplete="off"  :class="className.input" v-model="form.lname" placeholder="Last Name" required>
                                            <span class="text-red-700 mb-30" v-if="formErrors.lname" v-text="formErrors.lname"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-12 p-1">
                                    <div class="form-group">
                                        <input type="text" name="address" autocomplete="off"  :class="className.input" v-model="form.address" placeholder="Address" required>
                                        <span class="text-red-700 mb-30" v-if="formErrors.address" v-text="formErrors.address"/>
                                    </div>
                                </div>
                                <div class="lg:flex justify-content-between">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3 p-1">
                                        <div class="form-group">
                                            <input type="number" name="pincode" min="6" max="6" autocomplete="off"  :class="className.input" v-model="form.pincode" placeholder="Pincode" required @blur="getCity(form.pincode)">
                                            <span class="text-red-700 mb-30" v-if="formErrors.pincode" v-text="formErrors.pincode"/>
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3 p-1">
                                        <div class="form-group">
                                            <input type="text" name="name" autocomplete="off"  :class="className.input" v-model="form.city" placeholder="City" required>
                                            <span class="text-red-700 mb-30" v-if="formErrors.city" v-text="formErrors.city"/>
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3 p-1">
                                        <div class="form-group">
                                            <input type="text" name="name" autocomplete="off"  :class="className.input" v-model="form.state" placeholder="State" required>
                                            <span class="text-red-700 mb-30" v-if="formErrors.state" v-text="formErrors.state"/>
                                        </div>
                                    </div>
                                </div>
                                <div class=" my-4 flex justify-end">
                                    <button type="button" :class="className.button" @click="onNext">Next</button>
                                </div>

                            </div>
                        </form>
                        <!--  Step 2-->
                        <form v-if="broker" class="h-96">
                            <div class="overflow-hidden shadow sm:rounded-md px-4 sm:p-6 text-white">
                                <img class="w-full" src="/images/account-assets-audit-bank-bookkeeping-finance-concept.jpg" alt="Sunset in the mountains">
                                <div class="col-12 p-1">
                                    <div class="form-group mt-4">
                                        <input type="checkbox" value="true" id="flexCheckDefault" v-model="form.demat" >
                                        <label>Already have a Demat Account?</label>
                                        <div class="flex flex-row">
                                            <div class="flex items-center m-2">
                                                <input id="default-radio-1" type="radio" value="" name="default-radio" class="w-4 h-4" @change="checked = !checked" v-model="form.demat">
                                                <label for="default-radio-1" class="ml-2 text-sm font-medium">Yes</label>
                                            </div>
                                            <div class="flex items-center m-2">
                                                <input checked id="default-radio-2" type="radio" value="" name="default-radio" class="w-4 h-4" @change="checkedNo">
                                                <label for="default-radio-2" class="ml-2 text-sm font-medium ">No</label>
                                            </div>
                                        </div>
                                        <span class="text-red-700 mb-30" v-if="formErrors.address" v-text="formErrors.address"/>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-12 " v-if="checked">
                                    <label class="mt-4 text-sm font-semibold">Broker</label>
                                    <multiselect v-model="form.broker" :options="brokers" :multiple="false" :max-height="700" label="name" :class="className.input" size="30" @select="open"/>
                                    <span class="text-red-700 mb-30" v-if="formErrors.address" v-text="formErrors.address"/>
                                </div>
                                <div class="col-12 col-lg-12" v-if="openBroker">
                                    <div class="form-group">
                                        <label for="openBroker" class="mt-4 text-sm font-semibold">Broker Name</label>
                                        <input type="text" name="city" id="openBroker" autocomplete="off" :class="className.input" v-model="form.openBroker">
                                        <span class="text-red-700 mb-30" v-if="formErrors.openBroker" v-text="formErrors.openBroker"/>
                                    </div>
                                </div>
                                <div class=" my-4 flex justify-end">
                                    <button type="button" :class="className.button" @click="brokerCheck" >Next</button>
                                    <!-- </div> -->
                                </div>
                            </div>
                        </form>
                        <!--  Step 3-->
                        <form v-if="verification">
                            <div class="overflow-hidden shadow sm:rounded-md px-4 sm:p-6 text-white">
                                <img class="w-full" src="/images/account-assets-audit-bank-bookkeeping-finance-concept.jpg" alt="Sunset in the mountains">
                                <div class="my-3" v-if="!success">
                                    <input type="number" id="mobile" v-model="auth.mobile" :class="className.input" placeholder="Mobile Number" required/>
                                    <span class="text-red-700" v-if="authError.mobile" v-text="authError.mobile"/>
                                </div>
                                <div class="mb-3" v-if="!success">
                                    <input  type="email" name="email-address" id="email-address" v-model="auth.email" autocomplete="off" :class="className.input" placeholder="Email" required/>
                                    <span class="text-red-700" v-if="authError.email" v-text="authError.email"/>
                                </div>
                                <div class="mb-3" v-if="success">
                                    <input type="number" maxlength="6" :class="className.input" placeholder="OTP" v-model.number="auth.otp" oninput="if (value.length > maxLength) value = value.slice(0, maxLength);"/>
                                    <span class="text-red-700" v-if="authError.otp" v-text="authError.otp"/>
                                </div>
                                <div class=" my-4 flex justify-end">
                                    <button type="button" :class="className.button" @click="otpSubmit" >{{success ? 'Verify' : 'Get Otp'}}</button>
                                </div>
                            </div>
                        </form>
                        <!--  Step 3-->
                        <form v-if="id">
                            <div class="overflow-hidden shadow sm:rounded-md px-4 sm:p-6 text-white">
                                <img class="w-full" src="/images/account-assets-audit-bank-bookkeeping-finance-concept.jpg" alt="Sunset in the mountains">
                                <label for="file" class="my-6 flex flex-col justify-center items-center w-full h-54 border rounded-lg focus:border-white cursor-pointer">
                                    <div class="flex flex-col justify-center items-center py-8">
                                        <p class="mb-2 text-sm text-white dark:text-white">
                                            <span class="font-semibold">+</span>
                                            {{upload}}
                                        </p>
                                    </div>
                                    <input id="file" type="file" class="hidden" @change="getDocument($event)"/>
                                </label>
                                <span v-if="formErrors.id" class="text-red-700 mt-2" v-text="formErrors.id"></span>
                                <div class=" my-4 flex justify-end">
                                    <button type="button" :class="className.button" @click="onSubmit" >Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </main>
</template>

<script>
import {Multiselect} from "vue-multiselect";

export default {
    name: "authenticatoin",
    components: {
        Multiselect
    },
    data() {
        return {
            className: {
                label: 'block text-md font-medium text-gray-700',
                input: 'block py-2.5 px-0 w-full text-md text-white bg-transparent border-b-2 border-white appearance-none dark:text-white dark:border-white dark:focus:border-white focus:outline-none placeholder-white',
                button:'btn flex justify-self-end confer-btn my-4 border border-white rounded-full text-white'
            },
            brokers:[
                {name:'ZERODHA'},
                {name:'ICICI DIRECT'},
                {name:'HDFC SECURITIES'},
                {name:'ANGEL BROKING ( ANGEL ONE )'},
                {name:'5PAISA'},
                {name:'UPSTOX' },
                {name:'SHAREKHAN'},
                {name:'MOTILAL OSWAL'},
                {name:'KOTAK SECURITIES'},
                {name:'INDIA INFOLINE (IIFL)'},
                {name:'SBI CAP SECURITIES (SSL)'},
                {name:'CHOICE'},
                {name:'TRADE SMART'},
                {name:'PAYTM MONEY'},
                {name:'GROWW'},
                {name:'  AXIS DIRECT'},
                {name:'OTHER'},
            ],
            customer: {},
            form: {
                fname: null,
                lname: null,
                address: null,
                city: null,
                state: null,
                pincode: null,
                demat: 0,
                id:null,
                broker:null,
                openBroker:null,
                document:null,
                ip:null
            },
            formErrors: {
                fname: null,
                lname: null,
                address: null,
                city: null,
                state: null,
                pincode: null,
                demat: 0,
                id:null,
                broker:null,
                openBroker:null,
                document:null,
            },
            auth:{
                mobile:null,
                email:null,
                otp:null,
            },
            authError:{
                mobile:null,
                email:null,
                otp:null,
            },
            id:false,
            show:false,
            broker:false,
            personal:true,
            checked:false,
            success: false,
            openBroker:false,
            processing: false,
            verification:false,
            label: 'Send OTP',
            title:'Personal Details',
            address : null,
            upload:'Upload Id Proof'

        }
    },
    methods:{
        getCity(value){
            console.log(value);
            fetch(`https://api.postalpincode.in/pincode/${value}`)
                .then(response => response.json())
                .then(data => {
                    if (data[0].Status === 'Success') {
                        const postOffice = data[0].PostOffice[0];
                        this.form.city = `${postOffice.District}`;
                        this.form.state = `${postOffice.State}`;
                    } else {
                        this.address = 'PIN code not found';
                    }
                })
                .catch(error => {
                    console.error(error);
                    this.address = 'Error occurred while fetching address';
                });
        },
        storeInCookie() {
            localStorage.setItem('form', JSON.stringify(this.form))
        },
        async onNext(){
            try {
                let {data} = await axios.post(`/api/customers/validation`, this.form);
                if(data){
                    this.verification = true;
                    this.personal = false;
                    this.title = 'Authenticate Yourself'
                    this.storeInCookie();
                }
            } catch ({response}) {
                this.formErrors = {};
                if (response.data.errors) {
                    for (const [key, value] of Object.entries(response.data.errors)) {
                        this.formErrors[key] = value[0];
                    }
                }
            }
        },
        async otpSubmit() {
            try {
                if(this.success){
                    let {data} = await axios.post(`/api/otp/otp-validate`, this.auth);
                    if (data) {
                        this.$toast(data.message);
                        this.title = 'Authenticate Yourself'
                        this.broker = true;
                        this.verification = false;
                        this.storeInCookie();
                    }
                }else{
                    let {data} = await axios.post(`/api/otp/otp-request`, this.auth);
                    if (data) {
                        this.$toast(data.message);
                        this.success = true;

                    }
                }
            } catch ({response}) {
                console.log(response);
                this.formErrors = {};
                if (response.data.errors) {
                    for (const [key, value] of Object.entries(response.data.errors)) {
                        console.log(value);
                        this.authError[key] = value;
                    }
                }
            }
        },
        async onResend(){
            try {
                let {data} = await axios.post(`/api/otp/otp-resend`, this.auth);
                if (data) {
                    this.$toast(data.message);
                }
            } catch ({response}) {
                this.formErrors = {};
                if (response.data.errors) {
                    for (const [key, value] of Object.entries(response.data.errors)) {
                        this.authError[key] = value[0];
                    }
                }
            }
        },
        brokerCheck(){
            this.broker = false;
            this.id = true;
        },
        async onSubmit(){
            this.storeInCookie();
            const config = {
                headers: {
                    'content-type': 'multipart/form-data'
                }
            }
            await fetch('https://api.ipify.org?format=json')
                .then(x => x.json())
                .then(({ ip }) => {
                    this.form.ip = ip;

                });
            let formData = new FormData();
            formData.append('fname',this.form.fname);
            formData.append('lname',this.form.lname);
            formData.append('address',this.form.address);
            formData.append('city',this.form.city);
            formData.append('state',this.form.state);
            formData.append('pincode',this.form.pincode);
            formData.append('mobile',this.auth.mobile);
            formData.append('email',this.auth.email);
            formData.append('demat',this.form.demat);
            formData.append('id',this.form.id);
            formData.append('broker',this.form.broker.name);
            formData.append('openBroker',this.form.openBroker);
            formData.append('document',this.form.document);
            formData.append('ip',this.form.ip);
            try {
                let url = `/api/customers`;
                let {data} = await axios.post(url, formData, config);
                this.errors = {};
                this.$toast(data.message);
                this.customer = data.customer;
                localStorage.removeItem('form');
                await this.$router.push({name : 'policy', params:this.customer});
            } catch ({response}) {
                this.formErrors = {};
                if (response.data.errors) {
                    for (const [key, value] of Object.entries(response.data.errors)) {
                        this.authError[key] = value[0];
                    }
                }
            }
        },
        open(value){
            console.log(value);
            if(value.name === 'OTHER'){
                this.openBroker = !this.openBroker;
            }else{
                this.openBroker = false;
            }
            console.log(this.openBroker);

        },
        checkedNo(){
            this.checked = false;
            this.openBroker = false;
            this.form.broker = null;
        },
        getDocument(event) {
            this.upload = event.target.files[0].name;
            this.form.document = event.target.files[0];

        },
    },
    created() {
        let  form = localStorage.getItem('form')
        if(form){
            this.form = JSON.parse(form);
        }
    }
}
</script>

<style scoped>

</style>
